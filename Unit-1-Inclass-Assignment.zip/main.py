'''
Name: Alex K. Shibu
Date: Tues, Dec 10, 2020
Unit 1 Inclass Assignment
'''

# 1. Given a line segment with endpoints (x1, y1) and (x2, y2), you can determine the midpoint using the following formula:

'''
Input: Ask user to input the x and y coordinates of the first and second point (int)

Process: Use the formula to calculate the midpoint of the line using the x and y coordinates inputed (int)

Output: Display the midpoint on console (int)
'''


import math

#Input
x1 = input('The value of the x coordinate of the first point: ')
y1 = input('The value of the y coordinate of the first point: ')

x2 = input('The value of the x coordinate of the second point: ')
y2 = input('The value of the y coordinate of the second point: ')

#Processing
x_mid = (x1 + x2)/2
y_mid = (y1 + y2)/2

#Output
print "The midpoint of line is: (", x_mid,",", y_mid, ")"






# 2. Write a program that lets you enter side a,b and angle of C and use the cosine law to calculate the unknown sidelength c. Output your answer to one decimal place.  


'''
Input: Require used to input three values to begin the program. The length of side A, Side B and finally angle of C(int,float)
Process: Calculating the unknown sidelength using the given a,b length and C angle(int, float)
Output: The system outpots the unknown length of C (int, float)
'''


#Input: Require used to input three values to begin the program. The length of side A, Side B and finally angle of C
legA = input("Input the length of side A: ")
legB = input("Input the length of side B: ")
angC = input("Input the value of angle C: ")

#Process: Calculating the unknown sidelength using the given a,b 

angC = math.sqrt((legA**2)+(legB**2)-2+((legA)*(legB) * math.cos(angC)))

#Output: The system outputs the unknown length of C 
print "The length of side C is: ", round(angC,1)

